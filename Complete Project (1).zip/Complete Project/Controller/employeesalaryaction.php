<?php

require '../model/User.php';
session_start();

$salaryErr = $hrentErr = $otherErr = $totalErr = "";

  $slaery   =     "";
  $hrent      =     "";
  $other     =     "";
  $total   =     "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

    function test_input($data){
        $data  = trim($data);
        $data  = stripcslashes($data);
        $data  = htmlspecialchars($data);
        return $data;
    }

    $salary = test_input($_POST['salary']);
    $hrent = test_input($_POST['hrent']);
    $other = test_input($_POST['other']);
     $total = test_input($_POST['total']);
    
    

    $message = "";
    
    if (empty($salary)) {
        $message = "please enter slary";
        $salaryErr = "please enter salary";
    } 

    }
    if (empty($hrent)) {
            $message = "please enter house rent";
            $passwordErr = "please enter houserent";
    }


    if (empty($others)) {
        $message = "please enter value";
        $otherErr = "please enter value";
    } 
    if (empty($total)) {
        $message = "please enter value";
        $totalErr = "please enter value";
    } 



    if($message === "")
    {

      $flag  = salary($salary,$hrent,$other,$total);

      if(true){

        $_SESSION['is'] = "";

        $_SESSION['as'] = "Welcome.";
        header("Location: ../view/employeesalary.php");
      }
    }
    else{
      $_SESSION['as'] = "Successful";
      header("Location: ../view/employeesalary.php");
    }
    
        



?>