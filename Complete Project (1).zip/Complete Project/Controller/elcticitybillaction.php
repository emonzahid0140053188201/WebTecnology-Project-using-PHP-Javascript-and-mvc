<?php

require '../model/User.php';
session_start();

$paybill1Err = $paybill2Err = $paybill2Err = "";

  $paybill1   =     "";
  $paybill2      =     "";
  $paybill3     =     "";
  

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

    function test_input($data){
        $data  = trim($data);
        $data  = stripcslashes($data);
        $data  = htmlspecialchars($data);
        return $data;
    }

    $paybill1 = test_input($_POST['paybill1']);
    $patbill2 = test_input($_POST['paybill2']);
    $paybill3 = test_input($_POST['paybill3']);
    
    
    

    $message = "";
    
    if (empty($paybill1)) {
        $message = "please enter slary";
        $paybill1Err = "please enter salary";
    } 

    }
    if (empty($paybill2)) {
            $message = "please enter house rent";
            $paybill2Err = "please enter houserent";
    }


    if (empty($paybill3)) {
        $message = "please enter value";
        $paybill3Err = "please enter value";
    } 


    if($message === "")
    {

      $flag  = bill($paybill1,$paybill2,$paybill3);

      if(true){

        $_SESSION['is'] = "";

        $_SESSION['as'] = "Welcome.";
        header("Location: ../view/elcticitybill.php");
      }
    }
    else{
      $_SESSION['as'] = "successfull";
      header("Location: ../view/elcticitybill.php");
    }
    
        



?>