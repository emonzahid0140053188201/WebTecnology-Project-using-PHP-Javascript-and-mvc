<?php

require '../model/User.php';


$usernameErr = $emailErr = $genderErr = $passwordErr = "";

  $username   =     "";
  $email      =     "";
  $gender     =     "";
  $password   =     "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

    function test_input($data){
        $data  = trim($data);
        $data  = stripcslashes($data);
        $data  = htmlspecialchars($data);
        return $data;
    }

    $username = test_input($_POST['username']);
    $password = test_input($_POST['password']);
    $Email = test_input($_POST['email']);
    $gender = isset($_POST['gender']) ? test_input($_POST['gender']) : NULL;

    $message = "";
    
    if (empty($username)) {
        $message = "please enter username";
        $usernameErr = "please enter username";
    } 
    else {
        $username = test_input($_POST["username"]);

        if (!preg_match("/^[a-zA-Z-' ]*$/",$username)) {
            $message = "Only letters and white space allowed";
            $usernameErr = "Only letters and white space allowed";
        }
    }
    if (empty($password)) {
        $message = "please enter password";
        $passwordErr = "please enter password";
    }


    if (empty($Email)) {
        $message = "please enter email";
        $emailErr = "please enter email";
    } 
    else {
    
        if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
          $message = "Invalid email format";
          $emailErr = "Invalid email format";
      }
    }

    if (empty($gender)) {
        $message = "please select gender";
        $genderErr = "please select gender";
    } 

    if($message === "")
    {

      $flag  = registation($username,$password,$Email,$gender);

      if($flag){

        $_SESSION['is'] = "Welcome.";
        header("Location: ../view/login.php");
      }
    }
    else{
      $_SESSION['is'] = "Error";
      header("Location: ../view/registation.php");
    }
    
        


}
?>
