<?php 
	
	session_start();
	require('../model/User.php');
	

?>
<?php
	
	$Email =$emailErr= "";

	if ($_SERVER['REQUEST_METHOD']=== "POST"){

		 function test_input($data){
        $data  = trim($data);
        $data  = stripcslashes($data);
        $data  = htmlspecialchars($data);
        return $data;
	}

	$Email  = test_input($_POST['Email']);

	$message = "";

	if (empty($Email)) {
        $message = "please enter email";
        $emailErr = "please enter email";
    } 
    else {
    
        if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
          $message = "Invalid email format";
          $emailErr = "Invalid email format";
      }
  }

      if($message === "")
    {



      $flag  = update($Email);

      if(true){

        echo "Data Updated";
      }
    }
    else{
      echo "Data Updated";
    }
    }


?>