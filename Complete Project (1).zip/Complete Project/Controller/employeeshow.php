<?php
        $hostname  = "localhost";
		$username  = "root";
		$password  = "";
		$dbname    = "accounts";
		$conn  = mysqli_connect($hostname,$username,$password,$dbname);

if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	$q="SELECT * from elist";
	$result=$conn->query($q);
	$output='<table border="1" width=100%><tr><th>ID</th><th>Name</th><th>Gender</th><th>Salary</th></tr>';
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			$output.= "<tr><td>{$row["id"]}</td><td>{$row["name"]}</td><td>{$row["gender"]}</td><td>{$row["salary"]}</td></tr>";
		}
		$output.='</table>';
	}
	else
		echo "O results";
	
	
}

$conn->close();
echo $output;
?>
