<?php

require '../model/User.php';
session_start();

$bloodtestErr = $mctestErr = $ecgtestErr = $othertestErr = "";

  $bloodtest   =     "";
  $mctest      =     "";
  $ecgtest     =     "";
  $othertest   =     "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

    function test_input($data){
        $data  = trim($data);
        $data  = stripcslashes($data);
        $data  = htmlspecialchars($data);
        return $data;
    }

    $bloodtest = test_input($_POST['bloodtest']);
    $mctest = test_input($_POST['mctest']);
    $ecgtest = test_input($_POST['ecgtest']);
     $othertest = test_input($_POST['othertest']);
    
    

    $message = "";
    
    if (empty($bloodtest)) {
        $message = "please enter slary";
        $bloodtestErr = "please enter salary";
    } 

    }
    if (empty($mctest)) {
            $message = "please enter house rent";
            $mctestErr = "please enter houserent";
    }


    if (empty($ecgtest)) {
        $message = "please enter value";
        $ecgtestErr = "please enter value";
    } 
    if (empty($othertest)) {
        $message = "please enter value";
        $othertestErr = "please enter value";
    } 


    if($message === "")
    {

      $flag  = salary($bloodtest,$mctest,$ecgtest,$othertest);

      if(true){

        $_SESSION['is'] = "";

        $_SESSION['as'] = "Welcome.";
        header("Location: ../view/labfee.php");
      }
    }
    else{
      $_SESSION['as'] = "Successful";
      header("Location: ../view/labfee.php");
    }
    
        



?>