<?php 
	
	session_start();
	require('../model/User.php');
	

?>
<?php

	if ($_SERVER['REQUEST_METHOD']=== "POST"){

		 function test_input($data){
        $data  = trim($data);
        $data  = stripcslashes($data);
        $data  = htmlspecialchars($data);
        return $data;
}
        $output='<table border="1" width=100%><tr><th>ID</th><th>Email</th></tr>';
  if($data->num_rows>0)
  {
    while($row=$data->fetch_assoc())
    {
      $output.= "<tr><td>{$row["id"]}</td><td>{$row["name"]}</td><td>{$row["gender"]}</td><td>{$row["salary"]}</td></tr>";
    }
    $output.='</table>';
  }
  else
    echo "O results";
  
  

$conn->close();
echo $output;
	



	$search  = test_input($_POST['search']);

	$message = "";

	if (empty($search)) {
        $message = "please enter ID";
        $searchErr = "please enter ID";
    } 
    
      if($message === "")
    {

      $_SESSION['search'] =search($search);

      if(isset($_SESSION['search'])){

        $_SESSION['f1']= true;
        header("Location:../view/searchanything.php");
      }

      
      
    }
    else{
      header("Location:../view/searchanything.php");
    }

  }


?>