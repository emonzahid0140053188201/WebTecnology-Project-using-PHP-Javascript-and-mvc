<?php

require '../model/User.php';
session_start();

$equibmentbuyErr = $kitbuyErr = $furniturebuyErr = $itequibmentbuyErr = "";

  $equibmentbuy     =     "";
  $kitbuy           =     "";
  $furniturebuy     =     "";
  $itequibmentbuy   =     "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

    function test_input($data){
        $data  = trim($data);
        $data  = stripcslashes($data);
        $data  = htmlspecialchars($data);
        return $data;
    }

    $$equibmentbuy = test_input($_POST['equibmentbuy']);
    $$kitbuy  = test_input($_POST['kitbuy']);
    $furniturebuy = test_input($_POST['furniturebuy']);
     $itequibmentbuy = test_input($_POST['itequibmentbuy']);
    
    

    $message = "";
    
    if (empty($equibmentbuy)) {
        $message = "please enter slary";
        $equibmentbuyErr = "please enter salary";
    } 

    }
    if (empty($kitbuy)) {
            $message = "please enter house rent";
            $kitbuydErr = "please enter houserent";
    }


    if (empty($furniturebuy)) {
        $message = "please enter value";
        $furniturebuyErr = "please enter value";
    } 
    if (empty($itequibmentbuy)) {
        $message = "please enter value";
        $itequibmentbuybuyErr = "please enter value";
    } 



    if($message === "")
    {

      $flag  = salary($salary,$hrent,$other,$total);

      if(true){

        $_SESSION['is'] = "";

        $_SESSION['as'] = "Welcome.";
        header("Location: ../view/equibmentbuy.php");
      }
    }
    else{
      $_SESSION['as'] = "Successful";
      header("Location: ../view/equibmentbuy.php");
    }
    
        



?>