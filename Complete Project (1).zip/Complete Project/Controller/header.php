<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<h1>Welcome, Online Nursing System</h1><br><br>

	<fieldset>
<header class="design">
	
	<div class="signin">
		<a href="home.php">Home Page</a>
		<a href="employeesalary.php">Employee Salary</a>
		<a href="elcticitybill.php">Electicity Bill</a>
		<a href="equibmentbuy.php">Equibment Buy</a>
		<a href="cashmodule.php">Cash Module</a>
		<a href="labfee.php">Lab Fee</a>
		<a href="../Controller/logout.php">Logout</a>
		<a href="employee.php">Search Employee</a>
		<a href="changepass.php">Change Password</a>
		<a href="editprofile.php">Edit Profile</a>



	</div>
</header>
</fieldset>

</body>
</html>




