<?php
session_start();
require('../model/User.php');
?>




<?php



   // $uname = "";
   //  $pass = "";


   if($_SERVER['REQUEST_METHOD'] === "POST"){
    //if (isset($_POST["submit"])) {



      // function test_input($data) {
            // $data = trim($data);
            // $data = stripslashes($data);
             //$data = htmlspecialchars($data);
             //return $data;
        //}



       // $uname = $_POST['uname'];
       //  $pass = $_POST['pass'];



        $message = "";
       // //  if(empty($uname)){
       // //          $message .= "Username can't be Empty";
       // //          $message .= "<br>";
       // //      }



       // // if(empty($pass)){
       // //          $message .= "Password can't be Empty";
       // //          $message .= "<br>";
       //  }



   
        



               $flag = Checklogin($_POST['uname'],$_POST['pass']);

if ($message === ""){

        if($flag===true){

            if(isset($_POST['remember'])){

            setcookie('ucookie',$_POST["uname"],time()+(60*60*24));

            setcookie('pcookie',$_POST["pass"],time()+(60*60*24));

            header("Location: ../view/home.php");

        }



         // else if
         // {
         //            echo "Password / Username not correct.";
         //        }

        else{

            setcookie('ucookie','',time()-(60*60*24));

            setcookie('pcookie','',time()-(60*60*24));

        }



                    header("Location: ../view/home.php");
                }


        

            
    
      }
      }         
        
    
?>