
<?php
	
	
	if(isset($_SESSION['is'])){
		echo $_SESSION['is'];
	}
 require('../Controller/loginaction.php');

 

 if(isset($_COOKIE['ucookie']) && isset($_COOKIE['pcookie'])){

    $u=$_COOKIE['ucookie'];

    $p=$_COOKIE['pcookie'];

 }

 else{

    $u="";

    $p="";
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Page</title>
	
	<!-- <script src="JS/loginvalidaction.js"></script> -->
</head>

<body>
	<div class="center">
	<form class="form" method="post" action="<?php echo $_SERVER["PHP_SELF"];?>" onsubmit="return validate(this)">
		<fieldset class="backcolor">
			<legend>Login Page</legend><br>
			<label for="uname">User Name</label><br><br>
			<input type="text" id="uname" name="uname" placeholder="username" value="<?php echo $u ?>"><br>
			<span id="errusername"></span>


			<label for="pass">Password</label><br><br>
			<input type="text" id="pass" name="pass" placeholder="password" value="<?php echo $p ?>"><br>
			<span id="errpassword"></span>

			<label>
				<input type="checkbox" name="remember" id="remember">Remember me
			</label>
<br>


			<input type="submit" name="submit" value="Login"><br>
			<p>Don't have an account?</p>
		<a href="registation.php">Click here for registation!</a>
		</fieldset>
		
	</form>
</div>
	<br>
	<?php 

		include('footer.php')
	 ?>
	 
<script>
      function validate()
      {
         var username=document.getElementById('uname');
         var password=document.getElementById('pass');
         if(username.value=="" || password.value=="")
         {
             alert('Username or password cannot be empty');
             return false;
         }
          
         else{
            
             return true;
         }
      }
    </script>

    
</body>
</html>