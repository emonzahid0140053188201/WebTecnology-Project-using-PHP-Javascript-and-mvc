
<fieldset class="clr" >
	<p>"Weclome"</p>
	<p >"Copy Right 2022"</p>
	<p >"Thank You"</p>
</fieldset>
<link rel="stylesheet" type="text/css" href="style.css">

