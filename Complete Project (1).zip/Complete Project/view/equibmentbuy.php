<?php 
session_start();
require('../Controller/header.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Equibment Buy Page</title>
	<script src="JS/equibmentbuyvalidaction.js"></script>
</head>
<body>
	<form method="post" action="../Controller/equibmentbuyaction.php" notvalidate onsubmit= "return validate(this);">
		<fieldset>
			<legend>Equibment Buy Page</legend><br>
			
			<label for="equibmentbuy">Lab Equibment Buy Cost</label><br>
			<input type="text" id="equibmentbuy" name="equibmentbuy" value="lab equibment buy">
			<span id="equibmentbuyerr"></span>


			<br><br>
			

			<label for="kitbuy">testing kit Buy Cost</label><br>
			<input type="text" id="kitbuy" name="kitbuy" value="texting kit buy">
			<span id="kitbuyerr"></span>


			<br><br>
			

			<label for="furniturebuy">Furniture Buy Cost</label><br>
			<input type="text" id="furniturebuy" name="furniturebuy" value="furniture buy">
			<span id="furniturebuyerr"></span>

			<br><br>
			

			<label for="itequibmentbuy">IT Equibment Buy Cost</label><br>
			<input type="text" id="itequibmentbuy" name="itequibmentbuy" value="it equibment buy">
			<span id="itequibmentbuyerr"></span>

			<br><br>

			<input type="submit" name="add" value="ADD">

		</fieldset>
	</form>

	<?php 
		if(isset($_SESSION['as'])){
			echo $_SESSION['as'];
		}
	?>

</body>
</html>