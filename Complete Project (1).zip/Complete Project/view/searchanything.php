<?php 
	
	session_start();
	
	

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Search Page</title>
	<script src="JS/searchanythingvalidaction.js"></script>
</head>
<body>
	<form method="POST" action="../Controller/searchanythingaction.php" novalidate>
		<fieldset>
			<legend>Search Page</legend>

			<input type="text" id="serach" name="search" placeholder="Enter search">
			<span id="searchErr"></span>
			<input type="submit" id="submit" name="submit" value="serach">
			<span id="submitErr"></span>
		</fieldset>
	</form>
    <div id="main">
    </div>
    <script src="jquery.js"></script>
    <script>
        $(document).ready(function(){
            $("#submit").on("click",function(e){
                $.ajax({
                    url:"../Controller/searchanythingaction.php",
                    type:"POST",
                    success:function(data){
                        $("#main").html(data);
                    }
                });
            });
        });
    </script>

	<br><br><br>

</body>
</html>