<?php 
session_start();
require('../Controller/header.php');
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cash Module</title>
</head>
<body>
	<form>
		<fieldset>
			<legend>Cash Module Form</legend><br>
			<label>Pateint Pament</label><br>
			<input type="text" name="ppament" placeholder="please input"><br><br>
			<label>Supplier Pament</label><br>
			<input type="text" name="spament" placeholder="please input"><br><br>
			<label>Total Balance</label><br>
			<input type="text" name="ppament" placeholder="please input"><br><br>
			<label>Cash Transfar</label><br>
			<input type="text" name="tranfar" placeholder="please input"><br><br>
			<input type="submit" name="submit" value="submit">
		</fieldset>

	</form>
	<br>
	<?php 
		if(isset($_SESSION['as'])){
			echo $_SESSION['as'];

			
		}

	?>
	<?php 

	include('footer.php');

	?>

		



</body>
</html>