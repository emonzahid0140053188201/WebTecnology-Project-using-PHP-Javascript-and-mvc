<?php 
session_start();
require('../Controller/header.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Lab Fee Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="JS/labfeevalidaction.js"></script>
</head>
<body>
	<form method="post" action="../Controller/labfeeaction.php" notvalidate onsubmit= "return validate(this);">
		<fieldset>
			<legend>Lab Fee Documents Page</legend><br>

			<label for="bloodtest">Blood Test Report Eran</label><br>
			<input type="text" id="bloodtest" name="bloodtest">
			<span id="errbloodtest"></span>

			<br><br>

			<label for="mctest">MRI/CT Scan Test Report Eran</label><br>
			<input type="text" id="mctest" name="mctest">
			<span id="errmctest"></span>

			<br><br>


			<label for="ecgtest">ECS Test Report Eran</label><br>
			<input type="text" id="ecgtest" name="ecgtest">
			<span id="errecgtest"></span>

			<br><br>


			<label for="othertest">Other Test Report Eran</label><br>
			<input type="text" id="othertest" name="othertest">
			<span id="errothertest"></span>

			<br><br>

			<input type="submit" name="submit" value="submit">






		</fieldset>
	</form>
	<?php 
		if(isset($_SESSION['as'])){
			echo $_SESSION['as'];
		}
	?>

	<?php

	include('footer.php');

	 ?>

</body>
</html>