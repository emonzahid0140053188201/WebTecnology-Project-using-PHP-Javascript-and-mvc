<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Profile</title>
	<script src="JS/editprofileaction.js"></script>
</head>
<body>
	<form method="post" action="../Controller/editprofileaction.php" novalidate onsubmit="return validate(this);">
		<fieldset>
			<legend>Edit Profile Form</legend><br>
			<label for="Email">Email</label><br>
			<input type="text" id="Email" name="Email" placeholder="Enter your email" ><br>
			<span id="erremail"></span>
			<br>
			<input type="submit" name="submit" value="update">
		</fieldset>
	</form>

</body>
</html>