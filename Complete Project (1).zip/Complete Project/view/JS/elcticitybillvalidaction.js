function validate(pForm){

	let isvalid       = "";

	
	let errorpaybill1     =     document.getElementById("errpaybill1");
	let errorpaybill2     =     document.getElementById("errpaybill2");
	let errorpaybill3     =     document.getElementById("errpaybill3");

	if(pForm.paybill1.value === ""){
		errorpaybill1.innerHTML = "Please enter value"
		isvalid = "Not valid";
	}
	if(pForm.paybill2.value === ""){
		errorpaybill2.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}

	if(pForm.paybill3.value === ""){
		errorpaybill3.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}

	if(isvalid === ""){
		return true;
	}
	else{
		return false;
	}


}