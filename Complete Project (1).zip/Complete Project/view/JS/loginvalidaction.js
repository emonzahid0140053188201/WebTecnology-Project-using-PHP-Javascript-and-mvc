function search (pForm){

	let isvalid  = "";

	if(pForm.uname.value === ""){

		document.getElementById("errusername").innerHTML = "username can't empty";
		isvalid = "notvqlid";
	}
	if(pForm.pass.value === ""){

		document.getElementById("errpassword").innerHTML = "password can't empty";
		isvalid = "notvalid";
	}

	console.log("Password");
	if(isvalid === ""){

		console.log("Part 1");
		return true;

	}
	else{

		console.log("Part 2");
		return false;
	}
}