function validate(pForm){

	let isvalid       = "";

	
	let errorsalary      =     document.getElementById("errsalary");
	let errorhouserent   =     document.getElementById("errhrent");
	let errorother       =     document.getElementById("errother");
	let errortotal       =     document.getElementById("errtotal");

	if(pForm.salary.value === ""){
		errorsalary.innerHTML = "Please enter salary"
		isvalid = "Not valid";
	}
	if(pForm.hrent.value === ""){
		errorhouserent.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}
	if(pForm.other.value === ""){
		errorother.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}
	if(pForm.total.value === ""){
		errortotal.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}

	if(isvalid === ""){
		return true;
	}
	else{
		return false;
	}


}