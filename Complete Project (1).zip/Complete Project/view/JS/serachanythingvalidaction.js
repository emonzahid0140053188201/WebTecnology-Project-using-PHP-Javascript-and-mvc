function validate (pForm){

	let isvalid  = "";

	if(pForm.search.value === ""){

		document.getElementById("searchErr").innerHTML = "search box can't empty";
		isvalid = "notvqlid";
	}

	if(pForm.submit.value === ""){

		document.getElementById("submitErr").innerHTML = "search box can't empty";
		isvalid = "notvqlid";
	}
	
	
	if(isvalid === ""){

		return true;

	}
	else{
		return false;
	}
}