function validate(pForm){

	let isvalid       = "";

	
	let errorbloodtest      =     document.getElementById("errbloodtest");
	let errormctest   =     document.getElementById("errmctest");
	let errorecgtest       =     document.getElementById("errecgtest");
	let errorothertest       =     document.getElementById("errothertest");

	if(pForm.bloodtest.value === ""){
		errorbloodtest.innerHTML = "Please enter value"
		isvalid = "Not valid";
	}
	if(pForm.mctest.value === ""){
		errormctest.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}
	if(pForm.ecgtest.value === ""){
		errorecgtest.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}
	if(pForm.othertest.value === ""){
		errorothertest.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}

	if(isvalid === ""){
		return true;
	}
	else{
		return false;
	}


}