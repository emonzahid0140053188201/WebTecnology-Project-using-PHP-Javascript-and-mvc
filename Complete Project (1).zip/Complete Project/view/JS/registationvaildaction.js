function validate(pForm){

	let isvalid       = "";

	
	let erroruname   = document.getElementById("errusername");
	let errorpass   = document.getElementById("errpassword");
	let erroremail   = document.getElementById("erremail");
	let errorgen   = document.getElementById("errgender");

	if(pForm.username.value === ""){
		erroruname.innerHTML = "Please enter user  name"
		isvalid = "Not valid";
	}
	if(pForm.password.value === ""){
		errorpass.innerHTML = "Please enter password";
		isvalid = "Not valid";
	}
	if(pForm.email.value === ""){
		erroremail.innerHTML = "Please enter email";
		isvalid = "Not valid";
	}
	if(pForm.gender.value === ""){
		errorgen.innerHTML = "Please enter gender";
		isvalid = "Not valid";
	}

	if(isvalid === ""){
		return true;
	}
	else{
		return false;
	}


}