function validate(pForm){

	let isvalid       = "";

	
	let equibmentbuyerr      =     document.getElementById("equibmentbuy");
	let kitbuyerr            =     document.getElementById("kitbuy");
	let furniturebuyerr      =     document.getElementById("furniturebuy");
	let itequibmentbuyerr    =     document.getElementById("itequibmentbuy");

	if(pForm.equibmentbuy.value === ""){
		equibmentbuyerr.innerHTML = "Please enter value"
		isvalid = "Not valid";
	}
	if(pForm.kitbuy.value === ""){
		kitbuyerr.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}
	if(pForm.furniturebuy.value === ""){
		furniturebuyerr.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}
	if(pForm.itequibmentbuy.value === ""){
		itequibmentbuyerr.innerHTML = "Please enter value";
		isvalid = "Not valid";
	}

	if(isvalid === ""){
		return true;
	}
	else{
		return false;
	}


}