<?php

session_start();
  
  require('../Controller/header.php');
?>

<br><br>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home Page</title>
</head>
<body>
	<form >
		

	<?php 
	require('footer.php');

	?>


</body>
</html>