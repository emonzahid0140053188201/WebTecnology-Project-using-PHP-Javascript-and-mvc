<?php 
session_start();
require('../Controller/header.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Electicity Bill</title>
	<script src="JS/elcticitybillvalidaction.js"></script>
</head>
<body>
	<form method="post" action="../Controller/elcticitybillaction.php" notvalidate onsubmit= "return validate(this)";>
		<fieldset>
			<legend>Electitcity Bill Form</legend><br>
			<label for="paybill1">Pay Bill For 1st 4month</label><br>
			<input type="text" id="paybill1" name="paybill1" placeholder="please input">
			<span id="errpaybill1"></span>
			<br><br>
			

			<label for="paybill2">Pay Bill For 2nd 4month</label><br>
			<input type="text" id="paybill2" name="paybill2" placeholder="please input">
			<span id="errpaybill2"></span>

			<br><br>
			

			<label for="paybill3">Pay Bill For last 4month</label><br>
			<input type="text" id="paybill3" name="paybill3" placeholder="please input">
			<span id="errpaybill3"></span>

			<br><br>
			<input type="submit" name="submit" value="submit">
		</fieldset>

	</form>

	<?php 
		if(isset($_SESSION['as'])){
			echo $_SESSION['as'];
		}
	?>

	<?php 

		include('footer.php');

	?>

</body>
</html>