<?php 
session_start();
require('../Controller/header.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Employee Salary</title>
	<script src="JS/employeesalaryvalidaction.js"></script>
</head>
<body>
	<form method="post" action="../Controller/employeesalaryaction.php" notvalidate onsubmit= "return validate(this);">
		<fieldset>
			<legend>Employee Salary Page</legend><br>
			<label for="salary">Salary</label><br>
			<input type="text" id="salary" name="salary" placeholder="input salary">
			<span id="errsalary"></span><br><br>


			<label for="hrent">House Rent</label><br>
			<input type="text" id="hrent" name="hrent" placeholder="input house rent">
			<span id="errhrent"></span><br><br>


			<label for="other">Others</label><br>
			<input type="text" id="other" name="other" placeholder="input others">
			<span id="errother"></span>

			<br><br>


			<label for="total">Total</label><br>
			<input type="text" id="total" name="total" placeholder="input total">
			<span id="errtotal"></span>
			<br><br>

			<input type="submit" name="add" value="Add">

		</fieldset>
	</form>

	<?php 
		if(isset($_SESSION['is'])){
			echo $_SESSION['is'];

		}
	?>
	<?php

		require('footer.php');

	?>

</body>
</html>