<?php 
session_start();
require('../Controller/header.php');
?>

<!DOCTYPE html>
<html>
<head>
	
</head>
<body>

	<h2>To see employee list</h2>
	<button id="load">Click!</button>
	<div id="main">
	</div>
	<script src="jquery.js"></script>
	<script>
		$(document).ready(function(){
			$("#load").on("click",function(e){
				$.ajax({
					url:"../Controller/employeeshow.php",
					type:"POST",
					success:function(data){
						$("#main").html(data);
					}
				});
			});
		});
	</script>

	<?php 
		if(isset($_SESSION['as'])){
			echo $_SESSION['as'];
		}
	?>

	<?php 

		include('footer.php');

	?>

</body>
</html>