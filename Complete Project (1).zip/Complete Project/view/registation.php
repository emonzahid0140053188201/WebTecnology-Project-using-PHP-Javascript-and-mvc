<?php 
	require('../Controller/registationaction.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registation Page</title>
	<script src="JS/registationvaildaction.js"></script>
	
</head>
<body>
	<form class="form" method="post" action="../Controller/registationaction.php" notvalidate onsubmit= "return validate(this);">
		<fieldset class="backcolor" >
			<legend>Registation Form</legend>
			<label for="username">Username </label><br>
		 	<input  type="text" id="username" name="username" placeholder="Enter username">
		 	<span id="errusername"></span>
			
<br>

		<label for="password">Password </label><br>
		<input type="text" id="password" name="password" placeholder="Enter password" >
		<span id="errpassword"></span>

<br>

		<label for="email">Email </label><br>
		<input type="text" id="email" name="email" placeholder="Enter email" >
		<span id="erremail"></span>


<br>

		  Gender:<br>
		  <input type="radio" id="gender" name="gender">Female
		  <input type="radio" id="gender" name="gender">Male
		  <input type="radio" id="gender" name="gender">Other  
		  <span id="errgender"></span>
		  <br><br>






		<input type="submit" name="submit" value="Registation"><br><br>

		<p style="background-color: white;">Already have an account?</p>
		<a href="login.php" style="background-color: white">Click here for Log in!</a>

	</fieldset>	
		
	</form>
	

	<?php 

		include('footer.php')
	 ?>

</body>
</html>