<?php

require 'conect.php';

function registation($user,$pass,$e,$gen){
        $conn = connect();
        if($conn)
        {
            $statement = $conn->prepare("Insert INTO registation ( username,password, gender, email ) VALUES(?,?,?,?)");
            $statement->bind_param("ssss",   $username, $password,$email,$gender);



            $username = $user;
            $password = $pass;
            $email = $e;
            $gender = $gen;

            $statement->execute();
            // die($stmt->error);
            return true;
        }
        else{
            return false;
        }
    }


    function Checklogin($username, $password) {
        $conn = connect();
        if ($conn) {



           $sql = "SELECT id FROM registation WHERE username = '" . $username . "' and password = '" . $password . "'";



           $res = mysqli_query($conn, $sql);



           if ($res->num_rows === 1)
                return true;
            return false;
        }
    }

    function search($ID) {
        $conn = connect();
        if ($conn){
            $sql = "SELECT * FROM elist WHERE id = '$ID'";
            $res = mysqli_query($conn, $sql);
            $users = array();



           if ($res->num_rows > 0) {



               while($row = $res->fetch_assoc()) {
                    array_push($users, $row);
                }
                return $users;
            }
            else{
                $_SESSION['searcha'] = "No data found";
                $_SESSION['fl'] = false;
                header("Location: ../view/searchanything.php");
            }
        }
        //return array();
    }





function update($y){

}


function salary($z){
    
}
function bill($x){
    
}








     ?>       